public class Calculator {

    public static int plus(int num1, int num2) {
        int result = num1 + num2;
        return result;
    }

    public static int subtract(int num1, int num2) {
        int result = num1 - num2;
        return result;
    }

    public static int multiply(int num1, int num2) {
        int result = num1 * num2;
        return result;
    }

    public static int divide(int num1, int num2) {
        int result = num1 / num2;
        return result;
    }
}
